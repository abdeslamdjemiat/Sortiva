SORTIVA — Android APK project

هذا المشروع مجهز للبناء السحابي من الهاتف.

أسهل طريقة:
1) أنشئ مستودع GitHub جديد باسم Sortiva.
2) ارفع محتويات هذا المجلد إلى المستودع (وليس ملف ZIP نفسه إذا كان GitHub يسمح برفع الملفات مباشرة).
3) افتح تبويب Actions.
4) شغّل workflow باسم Build Sortiva APK.
5) بعد انتهاء البناء افتح نتيجة الـ workflow وحمّل artifact باسم Sortiva-debug-apk.
6) فك ZIP الناتج وستجد app-debug.apk.

ملاحظة: هذا APK تجريبي (debug) للتجربة على الهاتف. قبل Google Play نحتاج إصدار Release موقّع، ثم إضافة AdMob وسياسة الخصوصية.
