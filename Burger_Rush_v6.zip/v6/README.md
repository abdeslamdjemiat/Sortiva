# Burger Rush v6

Mobile restaurant-management game prototype built as a self-contained Android WebView app.

Features:
- Moving customer queue and patience meters
- Cook, prepare, assemble and serve loop
- Ingredient station with tap and drag interactions
- Burger recipes: Classic, Cheese, Double, Bacon Combo and Mega Meal
- Tips, ratings, combo streaks, XP and levels
- Staff automation
- Upgrades for grill, prep, service, patience, prices and staff
- District map with unlockable restaurants
- Missions and daily reward
- Local save using Android WebView storage
- Offline gameplay; no network is required
