# Burger Rush v5

Mobile fast-food management prototype.

## v5 gameplay
- Customer queue and individual orders
- Cook -> Prep -> Serve gameplay loop
- Order timer and customer loss
- Earnings, XP, levels and combos
- Upgrades for grill, prep, packing, pricing and staff
- Multiple menu items and city districts
- Daily reward and missions

Build with GitHub Actions using `.github/workflows/build.yml`.
