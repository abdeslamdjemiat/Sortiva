package com.burgerrush.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        WebView v=new WebView(this); v.setWebViewClient(new WebViewClient());
        WebSettings s=v.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        v.setOverScrollMode(WebView.OVER_SCROLL_NEVER); setContentView(v); v.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed(){ }
}
