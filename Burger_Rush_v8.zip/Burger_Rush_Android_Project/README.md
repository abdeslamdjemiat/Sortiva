# Burger Rush v7

Major gameplay upgrade: moving customer queue, order system, ingredient prep, grill timing, packing, serving, reputation, combo, upgrades, staff automation, city map and persistent progression.

GitHub Actions builds a debug APK and uploads it as Burger-Rush-v7-APK.
