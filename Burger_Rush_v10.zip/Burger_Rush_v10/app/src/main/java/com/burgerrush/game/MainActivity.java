
package com.burgerrush.game;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        game=new GameView(this); setContentView(game);
    }
    @Override public void onBackPressed(){ if(game.panel!=0){game.panel=0;game.invalidate();} }
}

class GameView extends View {
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Paint stroke=new Paint(Paint.ANTI_ALIAS_FLAG);
    Random rnd=new Random(4);
    float W,H,scale,dt; long last;
    int money=128, stars=12, xp=34, level=1, combo=0, panel=0;
    int selectedStation=0; float orderTime=32, cook=0, assemble=0, pack=0;
    boolean cooking=false, assembling=false, packing=false, ready=false;
    ArrayList<Customer> customers=new ArrayList<>(); ArrayList<Worker> workers=new ArrayList<>();
    ArrayList<Popup> popups=new ArrayList<>();
    String[] names={"CLASSIC","CHEESE","DOUBLE","MEGA"};
    int[] rewards={16,21,28,38};
    int order=1;
    float scroll=0, chefAnim=0;

    GameView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        for(int i=0;i<5;i++) customers.add(new Customer(-90-i*92, i%3));
        workers.add(new Worker(.35f,.56f,0)); workers.add(new Worker(.58f,.59f,1));
        last=System.nanoTime();
    }
    float sx(float v){return v*scale;}
    void bg(Canvas c){
        // deep sky + street + sidewalk
        p.setShader(new LinearGradient(0,0,0,H,Color.rgb(126,201,235),Color.rgb(244,220,165),Shader.TileMode.CLAMP));
        c.drawRect(0,0,W,H,p); p.setShader(null);
        p.setColor(0x66ffffff);
        for(int i=0;i<5;i++) c.drawCircle(W*(.08f+i*.23f),H*(.18f+(i%2)*.06f),sx(34),p);
        p.setColor(Color.rgb(93,87,84)); c.drawRect(0,H*.72f,W,H,p);
        p.setColor(0xffd6c09a); c.drawRect(0,H*.48f,W,H*.72f,p);
        p.setColor(0xffb89c70); for(int i=0;i<12;i++) c.drawRect(i*W/12,H*.66f,(i*W/12)+2,H*.72f,p);
    }
    void rr(Canvas c,float l,float t,float r,float b,float rad,int col){
        p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);
    }
    void txt(Canvas c,String s,float x,float y,float size,int col,Paint.Align a){
        p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(sx(size));p.setTypeface(Typeface.create("sans",Typeface.BOLD));p.setTextAlign(a);
        c.drawText(s,x,y,p);
    }
    void shadow(boolean on){p.setShadowLayer(on?sx(8):0,0,sx(4),0x55000000);}
    void drawTop(Canvas c){
        shadow(true);rr(c,sx(10),sx(10),W-sx(10),sx(70),sx(20),0xeeffffff);shadow(false);
        txt(c,"BURGER RUSH",sx(24),sx(47),18,0xff202833,Paint.Align.LEFT);
        rr(c,W-sx(250),sx(19),W-sx(154),sx(61),sx(14),0xfffff3d9);txt(c,"$ "+money,W-sx(202),sx(46),15,0xffdf7100,Paint.Align.CENTER);
        rr(c,W-sx(145),sx(19),W-sx(74),sx(61),sx(14),0xfffff3d9);txt(c,"★ "+stars,W-sx(110),sx(46),15,0xffd79a00,Paint.Align.CENTER);
        rr(c,W-sx(65),sx(19),W-sx(18),sx(61),sx(14),0xff26313d);txt(c,""+level,W-sx(41),sx(46),15,Color.WHITE,Paint.Align.CENTER);
        rr(c,sx(24),sx(78),W-sx(24),sx(85),4,0x55ffffff);
        rr(c,sx(24),sx(78),sx(24)+(W-sx(48))*(xp%100)/100f,sx(85),4,0xffff8a00);
    }
    void drawRestaurant(Canvas c){
        float top=H*.22f, left=sx(12), right=W-sx(12), bottom=H*.69f;
        shadow(true);rr(c,left,top,right,bottom,sx(28),0xfff8f7f2);shadow(false);
        rr(c,left+sx(10),top+sx(10),right-sx(10),top+sx(64),sx(18),0xffff8510);
        txt(c,"🍔  BURGER RUSH",W/2,top+sx(47),22,Color.WHITE,Paint.Align.CENTER);
        // awning
        for(int i=0;i<8;i++){int col=(i%2==0)?0xffff8510:0xffffe6c2;rr(c,left+sx(10+i*(right-left-20)/8),top+sx(62),left+sx(10+(i+1)*(right-left-20)/8),top+sx(84),4,col);}
        // windows
        rr(c,left+sx(24),top+sx(92),right-sx(24),top+sx(202),sx(18),0xff8bd3ec);
        p.setColor(0x44ffffff);for(int i=1;i<5;i++)c.drawRect(left+sx(24+i*(right-left-48)/5),top+sx(92),left+sx(26+i*(right-left-48)/5),top+sx(202),p);
        // kitchen counter
        shadow(true);rr(c,left+sx(14),top+sx(188),right-sx(14),bottom-sx(8),sx(18),0xff9b6244);shadow(false);
        drawStation(c,left+sx(25),top+sx(202),right-left-sx(50),sx(62),0,"GRILL","🔥");
        drawStation(c,left+sx(25),top+sx(274),right-left-sx(50),sx(62),1,"PREP","🥬");
        drawStation(c,left+sx(25),top+sx(346),right-left-sx(50),sx(62),2,"PACK","📦");
    }
    void drawStation(Canvas c,float x,float y,float w,float h,int id,String name,String emoji){
        int base=id==selectedStation?0xfffff0dc:0xffeee7df;
        shadow(true);rr(c,x,y,x+w,y+h,sx(17),base);shadow(false);
        rr(c,x+sx(9),y+sx(8),x+w-sx(9),y+sx(39),sx(10),0xff202a35);
        txt(c,emoji,x+w/2,y+sx(31),20,Color.WHITE,Paint.Align.CENTER);
        txt(c,name,x+w/2,y+h-sx(13),12,0xff27313a,Paint.Align.CENTER);
        if(id==0&&cooking) progress(c,x+sx(14),y+sx(46),w-sx(28),cook,"COOKING");
        if(id==1&&assembling) progress(c,x+sx(14),y+sx(46),w-sx(28),assemble,"ASSEMBLING");
        if(id==2&&packing) progress(c,x+sx(14),y+sx(46),w-sx(28),pack,"PACKING");
    }
    void progress(Canvas c,float x,float y,float w,float q,String label){
        rr(c,x,y,x+w,y+sx(7),4,0xffd9dee3);rr(c,x,y,x+w*q,y+sx(7),4,0xffff8510);
        txt(c,label,x+w/2,y+sx(21),9,0xff6b737a,Paint.Align.CENTER);
    }
    void drawOrder(Canvas c){
        float y=H*.11f;
        shadow(true);rr(c,sx(12),y,W-sx(12),y+sx(72),sx(18),0xf9ffffff);shadow(false);
        txt(c,order==0?"👨":order==1?"👩":order==2?"🧔":"👩‍🦱",sx(42),y+sx(39),30,Color.DKGRAY,Paint.Align.CENTER);
        txt(c,names[order]+" BURGER",sx(70),y+sx(27),14,0xff1e2730,Paint.Align.LEFT);
        txt(c,order==3?"DOUBLE MEAT • CHEESE • LETTUCE":"BEEF • "+(order==0?"LETTUCE":order==1?"CHEESE":"CHEESE • LETTUCE"),sx(70),y+sx(49),10,0xff68737b,Paint.Align.LEFT);
        txt(c,String.format("00:%02d",Math.max(0,(int)orderTime)),W-sx(48),y+sx(39),14,orderTime<8?0xffe4452e:0xff26313c,Paint.Align.CENTER);
    }
    void drawCustomers(Canvas c){
        for(Customer q:customers){
            q.x+=q.speed*dt;
            float target=W*.32f + q.slot*W*.11f;
            if(q.x>target)q.x=target;
            float yy=H*.72f-sx(8);
            txt(c,q.face,q.x,yy,42,Color.DKGRAY,Paint.Align.CENTER);
            if(q.x>W*.31f && q.x<W*.72f) {
                rr(c,q.x-sx(22),yy-sx(58),q.x+sx(22),yy-sx(52),4,0xffd8dee2);
                rr(c,q.x-sx(22),yy-sx(58),q.x-sx(22)+sx(44)*Math.max(0,q.patience),yy-sx(52),4,0xffff5b3d);
            }
        }
    }
    void drawWorkers(Canvas c){
        chefAnim+=dt*8;
        for(int i=0;i<workers.size();i++){
            Worker w=workers.get(i); w.t+=dt*w.speed;
            float x=sx(70)+(float)Math.abs(Math.sin(w.t))*W*.65f;
            float y=H*.53f + (float)Math.sin(w.t*1.4f)*sx(8);
            txt(c,i==0?"👨‍🍳":"🧑‍🍳",x,y,40,Color.DKGRAY,Paint.Align.CENTER);
        }
    }
    void drawBottom(Canvas c){
        float y=H*.77f;
        shadow(true);rr(c,sx(10),y,W-sx(10),H-sx(12),sx(24),0xf9ffffff);shadow(false);
        txt(c,"INGREDIENTS",sx(24),y+sx(25),11,0xff68737b,Paint.Align.LEFT);
        String[] icons={"🍞","🥩","🥬","🧀","🥫","🍟"};
        String[] lab={"BUN","MEAT","LETTUCE","CHEESE","SAUCE","FRIES"};
        for(int i=0;i<6;i++){
            float x=sx(48)+i*(W-sx(96))/5f;
            rr(c,x-sx(25),y+sx(38),x+sx(25),y+sx(88),sx(14),0xfff0f2f3);
            txt(c,icons[i],x,y+sx(64),23,Color.DKGRAY,Paint.Align.CENTER);
            txt(c,lab[i],x,y+sx(103),8,0xff59636c,Paint.Align.CENTER);
        }
        float by=y+sx(116);
        button(c,sx(20),by,sx(125),sx(47),"🔥 COOK",selectedStation==0);
        button(c,sx(152),by,sx(125),sx(47),"🥬 PREP",selectedStation==1);
        button(c,sx(284),by,sx(105),sx(47),"📦 PACK",selectedStation==2);
        button(c,sx(396),by,sx(100),sx(47),"✓ SERVE",ready);
    }
    void button(Canvas c,float x,float y,float w,float h,String s,boolean active){
        rr(c,x,y,x+w,y+h,sx(14),active?0xffff8510:0xff202a35);
        txt(c,s,x+w/2,y+h/2+sx(1),11,Color.WHITE,Paint.Align.CENTER);
    }
    @Override protected void onDraw(Canvas c){
        W=getWidth();H=getHeight();scale=Math.max(.75f,W/420f);
        long now=System.nanoTime();dt=Math.min(.05f,(now-last)/1e9f);last=now;
        update();
        bg(c);drawRestaurant(c);drawOrder(c);drawCustomers(c);drawWorkers(c);drawBottom(c);
        if(panel!=0) drawPanel(c);
        for(Popup z:popups){z.y-=dt*35;z.life-=dt;txt(c,z.s,z.x,z.y,16,z.col,Paint.Align.CENTER);}
        invalidate();
    }
    void update(){
        if(cooking){cook+=dt/2.6f;if(cook>=1){cook=1;cooking=false;assembling=true;selectedStation=1;addPop("🔥 MEAT READY",W/2,H*.47f,0xffff7b00);}}
        if(assembling){assemble+=dt/2.9f;if(assemble>=1){assemble=1;assembling=false;packing=true;selectedStation=2;addPop("🥬 BURGER BUILT",W/2,H*.47f,0xff36a657);}}
        if(packing){pack+=dt/2.0f;if(pack>=1){pack=1;packing=false;ready=true;selectedStation=2;addPop("📦 READY TO SERVE",W/2,H*.47f,0xff1688d8);}}
        if(cooking||assembling||packing){orderTime-=dt;if(orderTime<=0){orderTime=32;resetOrder();combo=0;addPop("CUSTOMER LEFT",W/2,H*.47f,0xffe84b37);}}
        for(Customer q:customers)q.patience=Math.max(0,q.patience-dt*.004f);
    }
    void serve(){
        if(!ready){addPop("FINISH THE ORDER FIRST",W/2,H*.47f,0xffe84b37);return;}
        int earn=rewards[order]+Math.max(0,(int)orderTime/3)+combo*2;
        money+=earn;stars+=1;xp+=13;combo++;
        addPop("+$"+earn+"  COMBO x"+combo,W/2,H*.47f,0xffff8510);
        order=(order+1)%4;resetOrder();
    }
    void resetOrder(){orderTime=32;cook=assemble=pack=0;cooking=assembling=packing=ready=false;selectedStation=0;}
    void act(int id){
        selectedStation=id;
        if(id==0&&!cooking&&!assembling&&!packing&&!ready){cooking=true;cook=0;addPop("🔥 GRILL STARTED",W/2,H*.47f,0xffff8510);}
        else if(id==1&&!assembling&&cook>=1){assembling=true;assemble=0;}
        else if(id==2&&!packing&&assemble>=1){packing=true;pack=0;}
        else if(id==3)serve();
        else if(id<3) addPop(id==0?"ALREADY COOKING":"FINISH PREVIOUS STEP",W/2,H*.47f,0xffe84b37);
    }
    void drawPanel(Canvas c){
        p.setColor(0x990b1118);c.drawRect(0,0,W,H,p);
        float top=H*.25f;shadow(true);rr(c,sx(12),top,W-sx(12),H-sx(12),sx(26),Color.WHITE);shadow(false);
        if(panel==1){
            txt(c,"🔧  RESTAURANT UPGRADES",W/2,top+sx(40),19,0xff202a33,Paint.Align.CENTER);
            card(c,top+sx(72),"🔥 GRILL SPEED","Faster cooking",30);
            card(c,top+sx(138),"👨‍🍳 STAFF","Unlock worker",75);
            card(c,top+sx(204),"💰 PRICES","More profit",120);
            card(c,top+sx(270),"🏪 RESTAURANT","Bigger capacity",200);
        } else {
            txt(c,"🗺️  BURGER CITY",W/2,top+sx(40),19,0xff202a33,Paint.Align.CENTER);
            card(c,top+sx(72),"🍔 DOWNTOWN","OPEN",0);
            card(c,top+sx(138),"🌴 BEACH GRILL","LEVEL 4",0);
            card(c,top+sx(204),"🌃 NEON DINER","LEVEL 8",0);
            card(c,top+sx(270),"🏙️ SKY TOWER","LEVEL 15",0);
        }
        button(c,sx(35),H-sx(70),W-sx(70),sx(45),"← BACK",false);
    }
    void card(Canvas c,float y,String a,String b,int cost){
        rr(c,sx(28),y,W-sx(28),y+sx(55),sx(15),0xfff0f2f3);
        txt(c,a,sx(44),y+sx(22),13,0xff26313c,Paint.Align.LEFT);txt(c,b,sx(44),y+sx(41),9,0xff727b83,Paint.Align.LEFT);
        if(cost>0)txt(c,"$ "+cost,W-sx(55),y+sx(31),11,0xffff8510,Paint.Align.CENTER);
    }
    void addPop(String s,float x,float y,int col){popups.add(new Popup(s,x,y,col));if(popups.size()>8)popups.remove(0);}
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX(),y=e.getY();
        if(panel!=0){ if(y>H-sx(95)){panel=0;invalidate();} return true; }
        float by=H*.77f+sx(116);
        if(y>by&&y<by+sx(60)){
            if(x<sx(145))act(0);
            else if(x<sx(280))act(1);
            else if(x<sx(390))act(2);
            else act(3);
            return true;
        }
        // tap upper left/right empty HUD zones for management
        if(y<sx(85)&&x>W-sx(150)){panel=2;return true;}
        if(y<sx(85)&&x<sx(145)){panel=1;return true;}
        return true;
    }
    static class Customer{float x,slot,speed,patience=1;String face;Customer(float a,int s){x=a;slot=s;speed=25+s*6;face=new String[]{"👨","👩","🧔","👩‍🦱","👨‍🦱"}[s%5];}}
    static class Worker{float x,y,t,speed;int id;Worker(float a,float b,int i){x=a;y=b;id=i;t=i*2;speed=1+i*.18f;}}
    static class Popup{String s;float x,y,life=1.3f;int col;Popup(String a,float b,float c,int d){s=a;x=b;y=c;col=d;}}
}
