Burger Rush 9.0
A redesigned vertical mobile restaurant-management game.
Build with GitHub Actions or Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17.
