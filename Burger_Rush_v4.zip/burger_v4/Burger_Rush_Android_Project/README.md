# Burger Rush v4

A mobile-first idle restaurant game prototype with autonomous staff, customer queue, upgrades, menu unlocks, missions, districts, daily reward and persistent progress.

Build with Android Studio/Gradle or use the included GitHub Actions workflow.
